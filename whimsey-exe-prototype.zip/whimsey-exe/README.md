# WHIMSEY.exe — sushizy

A mobile-first interactive album website prototype built with plain HTML, CSS and JavaScript.

## Preview locally
Open `index.html` in a browser.

## Publish with GitHub Pages from iPhone
1. Create a public repository named `whimsey` (or another name you like).
2. Upload `index.html` to the repository root using **Add file → Upload files**.
3. Open **Settings → Pages**.
4. Under build/deployment, select **Deploy from a branch**, branch `main`, folder `/(root)`, then Save.
5. Wait for deployment. The URL will be `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## Customize later
- Track names and audio paths are in the `sampleTracks` array near the bottom of `index.html`.
- To add a preview, upload an audio file (for example `audio/track-01.mp3`) and set that track's `audio` value to `audio/track-01.mp3`.
- Replace the four CSS-generated art cards with `<img>` elements when you have personal photos.
- Update social links in the About app.
- Replace sample notes and temporary titles with your own material before public launch.

No framework, build step, API key, paid service, or backend is required. Audio is not included in this prototype.
